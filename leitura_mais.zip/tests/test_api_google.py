import requests

def testar_api_google_livros(titulo, autor):
    query = f"{titulo} {autor}"
    url = f"https://www.googleapis.com/books/v1/volumes?q={query}"

    try:
        response = requests.get(url, timeout=10)
        status = response.status_code
        data = response.json()
        capa = None

        if "items" in data and data["items"]:
            volume_info = data["items"][0].get("volumeInfo", {})
            image_links = volume_info.get("imageLinks", {})
            capa = image_links.get("thumbnail") or image_links.get("smallThumbnail")

        return {
            "status": status,
            "tem_items": "items" in data,
            "tem_capa": capa is not None,
            "capa_url": capa
        }
    except Exception as e:
        return {"erro": str(e)}

# Teste com título e autor genéricos
print(testar_api_google_livros("O Senhor dos Anéis", "J.R.R. Tolkien"))