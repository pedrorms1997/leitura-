from django.apps import AppConfig


class RecomendacoesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recomendacoes'
